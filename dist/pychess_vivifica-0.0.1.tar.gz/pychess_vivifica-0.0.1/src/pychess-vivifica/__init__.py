'''
This is a python package for chess.
'''

__author__ = "Jingyang Wang"
__email__ = "wangjy2010@126.com"
__version__ = "0.0.1"