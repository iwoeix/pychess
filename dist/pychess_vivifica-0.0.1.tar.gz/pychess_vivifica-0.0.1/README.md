# pychess
A python package for chess